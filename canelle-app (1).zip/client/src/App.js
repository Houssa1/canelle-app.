import React, {useEffect, useState} from 'react';
function Nav({setPage}) {
  return (
    <nav className="nav">
      <button onClick={()=>setPage('dashboard')}>Dashboard</button>
      <button onClick={()=>setPage('orders')}>Orders</button>
      <button onClick={()=>setPage('menu')}>Menu</button>
      <button onClick={()=>setPage('stock')}>Stock</button>
      <button onClick={()=>setPage('finance')}>Finance</button>
      <button onClick={()=>setPage('reports')}>Reports</button>
    </nav>
  );
}

function Dashboard() {
  const [summary, setSummary] = useState(null);
  const fetchSummary = async ()=> {
    const res = await fetch('/reports/daily');
    const data = await res.json();
    setSummary(data);
  };
  useEffect(()=>{ fetchSummary(); }, []);
  return (
    <div>
      <h2>Dashboard</h2>
      {summary ? (
        <div className="card">
          <div>Income: {summary.income.toFixed(2)}</div>
          <div>Expenses: {summary.expense.toFixed(2)}</div>
          <div>COGS: {summary.cogs.toFixed(2)}</div>
          <div><strong>Profit: {summary.profit.toFixed(2)}</strong></div>
        </div>
      ) : <div>Loading...</div>}
    </div>
  );
}

function Orders() {
  const [menu, setMenu] = useState([]);
  const [cart, setCart] = useState([]);
  const [orders, setOrders] = useState([]);
  useEffect(()=>{ fetch('/menu/items').then(r=>r.json()).then(setMenu); fetchOrders(); }, []);
  function addToCart(item){
    const found = cart.find(c=>c.id===item.id);
    if(found) setCart(cart.map(c=> c.id===item.id? {...c, qty: c.qty+1} : c));
    else setCart([...cart, {...item, qty:1}]);
  }
  function changeQty(id, delta){
    setCart(cart.map(c=> c.id===id? {...c, qty: Math.max(1,c.qty+delta)}:c));
  }
  async function submitOrder(){
    if(cart.length===0) return alert('Cart is empty');
    const payload = { server_id: 1, table_number: 'T1', items: cart.map(c=> ({id:c.id, qty:c.qty}))};
    const res = await fetch('/orders', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(payload)});
    const j = await res.json();
    alert('Order created: '+ j.order_id);
    setCart([]);
    fetchOrders();
  }
  async function fetchOrders(){ const r = await fetch('/orders'); setOrders(await r.json()); }
  async function pay(id){ await fetch(`/orders/${id}/pay`, {method:'POST'}); fetchOrders(); alert('Paid'); }

  return (
    <div>
      <h2>Orders</h2>
      <div className="layout">
        <div className="panel">
          <h3>Menu</h3>
          <ul className="list">
            {menu.map(m=> <li key={m.id}><button onClick={()=>addToCart(m)}>{m.name} — {m.price.toFixed(2)}</button></li>)}
          </ul>
        </div>
        <div className="panel">
          <h3>Cart</h3>
          <ul className="list">
            {cart.map(c=> <li key={c.id}>{c.name} x {c.qty} 
              <button onClick={()=>changeQty(c.id,-1)}>-</button>
              <button onClick={()=>changeQty(c.id,1)}>+</button>
            </li>)}
          </ul>
          <div><button onClick={submitOrder}>Submit Order</button></div>
        </div>
        <div className="panel">
          <h3>Recent Orders</h3>
          <ul className="list">
            {orders.map(o=> <li key={o.id}>#{o.id} {o.table_number} {o.status} {o.total_price.toFixed(2)}
              {o.status!=='paid' && <button onClick={()=>pay(o.id)}>Pay</button>}
            </li>)}
          </ul>
        </div>
      </div>
    </div>
  );
}

function MenuAdmin() {
  const [items, setItems] = useState([]);
  const [cats, setCats] = useState([]);
  const [name,setName]=useState(''); const [price,setPrice]=useState('');
  const [cat,setCat]=useState('');
  useEffect(()=>{ fetchItems(); fetch('/menu/categories').then(r=>r.json()).then(setCats); }, []);
  function fetchItems(){ fetch('/menu/items').then(r=>r.json()).then(setItems); }
  async function addItem(){
    await fetch('/menu/items', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({name,price:parseFloat(price), category_id: cat||null})});
    setName(''); setPrice(''); fetchItems();
  }
  return (
    <div>
      <h2>Menu Management</h2>
      <div className="card">
        <div>
          <input placeholder="Name" value={name} onChange={e=>setName(e.target.value)} />
          <input placeholder="Price" value={price} onChange={e=>setPrice(e.target.value)} />
          <select value={cat} onChange={e=>setCat(e.target.value)}>
            <option value="">--Category--</option>
            {cats.map(c=> <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
          <button onClick={addItem}>Add Item</button>
        </div>
      </div>
      <h3>Items</h3>
      <ul className="list">
        {items.map(i=> <li key={i.id}>{i.name} — {i.price.toFixed(2)} ({i.category_name || 'uncategorized'})</li>)}
      </ul>
    </div>
  );
}

function Stock() {
  const [stock,setStock] = useState([]);
  const [name,setName]=useState(''); const [unit,setUnit]=useState('pcs'); const [qty,setQty]=useState(''); const [cost,setCost]=useState('');
  useEffect(()=>{ fetchStock(); }, []);
  function fetchStock(){ fetch('/stock').then(r=>r.json()).then(setStock); }
  async function add(){ await fetch('/stock', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({name,unit,quantity:parseFloat(qty)||0,cost_per_unit:parseFloat(cost)||0})}); setName(''); setQty(''); setCost(''); fetchStock(); }
  return (
    <div>
      <h2>Stock</h2>
      <div className="card">
        <input placeholder="Name" value={name} onChange={e=>setName(e.target.value)} />
        <input placeholder="Unit" value={unit} onChange={e=>setUnit(e.target.value)} />
        <input placeholder="Quantity" value={qty} onChange={e=>setQty(e.target.value)} />
        <input placeholder="Cost per unit" value={cost} onChange={e=>setCost(e.target.value)} />
        <button onClick={add}>Add Stock</button>
      </div>
      <ul className="list">
        {stock.map(s=> <li key={s.id}>{s.name} — {s.quantity} {s.unit} (cost {s.cost_per_unit})</li>)}
      </ul>
    </div>
  );
}

function Finance(){
  const [list,setList]=useState([]); const [type,setType]=useState('expense'); const [desc,setDesc]=useState(''); const [amt,setAmt]=useState('');
  useEffect(()=>{ fetch('/finance').then(r=>r.json()).then(setList); }, []);
  async function add(){ await fetch('/finance', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({type,description:desc,amount:parseFloat(amt)})}); setDesc(''); setAmt(''); setList((await (await fetch('/finance')).json())); }
  return (
    <div>
      <h2>Finance</h2>
      <div className="card">
        <select value={type} onChange={e=>setType(e.target.value)}><option value="income">Income</option><option value="expense">Expense</option></select>
        <input placeholder="Description" value={desc} onChange={e=>setDesc(e.target.value)} />
        <input placeholder="Amount" value={amt} onChange={e=>setAmt(e.target.value)} />
        <button onClick={add}>Add</button>
      </div>
      <ul className="list">
        {list.map(l=> <li key={l.id}>{l.type} — {l.description} — {l.amount} ({l.created_at})</li>)}
      </ul>
    </div>
  );
}

function Reports(){
  const [report,setReport]=useState(null);
  useEffect(()=>{ fetch('/reports/daily').then(r=>r.json()).then(setReport); }, []);
  return (
    <div>
      <h2>Reports</h2>
      {report ? <pre>{JSON.stringify(report, null, 2)}</pre> : <div>Loading...</div>}
    </div>
  );
}

export default function App(){
  const [page, setPage] = useState('dashboard');
  return (
    <div>
      <header><h1>Canelle — Restaurant</h1></header>
      <Nav setPage={setPage} />
      <main>
        {page==='dashboard' && <Dashboard/>}
        {page==='orders' && <Orders/>}
        {page==='menu' && <MenuAdmin/>}
        {page==='stock' && <Stock/>}
        {page==='finance' && <Finance/>}
        {page==='reports' && <Reports/>}
      </main>
    </div>
  );
}
