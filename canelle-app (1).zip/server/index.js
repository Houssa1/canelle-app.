const express = require('express');
const db = require('./db');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
const SECRET = process.env.SECRET || "canelle_secret_key";
app.use(cors());
app.use(bodyParser.json());

// Initialize DB schema
db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    role TEXT,
    password_hash TEXT
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS stock (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    unit TEXT,
    quantity REAL,
    cost_per_unit REAL
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS menu_categories (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS menu_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    category_id INTEGER,
    name TEXT,
    price REAL,
    FOREIGN KEY(category_id) REFERENCES menu_categories(id)
  )`);

  // mapping menu items to stock ingredients with qty needed per serving
  db.run(`CREATE TABLE IF NOT EXISTS menu_item_ingredients (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    menu_item_id INTEGER,
    stock_id INTEGER,
    qty_per_serving REAL
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    server_id INTEGER,
    table_number TEXT,
    status TEXT,
    total_price REAL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS order_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id INTEGER,
    menu_item_id INTEGER,
    item_name TEXT,
    qty REAL,
    price REAL
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS income_expenses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    type TEXT,
    description TEXT,
    amount REAL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);

  // create a default admin if none exists
  const bcrypt = require('bcryptjs');
  db.get("SELECT COUNT(*) AS c FROM users", [], (err,row) => {
    if (row && row.c === 0) {
      const pw = bcrypt.hashSync('admin123', 8);
      db.run("INSERT INTO users(name,role,password_hash) VALUES(?,?,?)", ['admin','admin',pw]);
      console.log("Created default admin (name: admin password: admin123)");
    }
  });
});

// --------- AUTH ----------
app.post('/auth/login', (req,res) => {
  const {name, password} = req.body;
  db.get("SELECT * FROM users WHERE name = ?", [name], async (err,user) => {
    if (err) return res.status(500).json({error: err.message});
    if (!user) return res.status(404).json({error: 'User not found'});
    const ok = await bcrypt.compare(password, user.password_hash);
    if (!ok) return res.status(403).json({error: 'Wrong password'});
    const token = jwt.sign({id:user.id, role:user.role, name:user.name}, SECRET);
    res.json({token, user: {id:user.id, name:user.name, role:user.role}});
  });
});

// simple middleware to decode token (not enforcing in every endpoint for brevity)
function authMiddleware(req,res,next){
  const auth = req.headers.authorization;
  if (!auth) return next();
  const parts = auth.split(' ');
  if (parts.length !== 2) return next();
  const token = parts[1];
  try {
    const data = jwt.verify(token, SECRET);
    req.user = data;
  } catch(e){}
  return next();
}
app.use(authMiddleware);

// ---------- MENU: categories & items -----------
app.get('/menu/categories', (req,res) => {
  db.all("SELECT * FROM menu_categories", [], (err,rows) => {
    if (err) return res.status(500).json({error: err.message});
    res.json(rows);
  });
});

app.post('/menu/categories', (req,res) => {
  const {name} = req.body;
  db.run("INSERT INTO menu_categories(name) VALUES(?)", [name], function(err){
    if (err) return res.status(500).json({error: err.message});
    res.json({id: this.lastID});
  });
});

app.get('/menu/items', (req,res) => {
  db.all(`SELECT menu_items.*, menu_categories.name AS category_name
          FROM menu_items LEFT JOIN menu_categories
          ON menu_items.category_id = menu_categories.id
          ORDER BY menu_items.name`, [], (err,rows) => {
    if (err) return res.status(500).json({error: err.message});
    res.json(rows);
  });
});

app.post('/menu/items', (req,res) => {
  const {category_id, name, price} = req.body;
  db.run("INSERT INTO menu_items(category_id,name,price) VALUES(?,?,?)", [category_id || null, name, price], function(err){
    if (err) return res.status(500).json({error: err.message});
    res.json({id: this.lastID});
  });
});

app.put('/menu/items/:id', (req,res) => {
  const {category_id, name, price} = req.body;
  db.run("UPDATE menu_items SET category_id=?, name=?, price=? WHERE id=?", [category_id || null, name, price, req.params.id], function(err){
    if (err) return res.status(500).json({error: err.message});
    res.json({success:true});
  });
});

app.delete('/menu/items/:id', (req,res) => {
  db.run("DELETE FROM menu_items WHERE id=?", [req.params.id], function(err){
    if (err) return res.status(500).json({error: err.message});
    res.json({success:true});
  });
});

// menu item ingredients (map menu items to stock)
app.get('/menu/:id/ingredients', (req,res) => {
  db.all(`SELECT mii.*, s.name AS stock_name, s.unit FROM menu_item_ingredients mii
          LEFT JOIN stock s ON mii.stock_id = s.id
          WHERE mii.menu_item_id = ?`, [req.params.id], (err,rows) => {
    if (err) return res.status(500).json({error: err.message});
    res.json(rows);
  });
});

app.post('/menu/:id/ingredients', (req,res) => {
  const menu_item_id = req.params.id;
  const {stock_id, qty_per_serving} = req.body;
  db.run("INSERT INTO menu_item_ingredients(menu_item_id, stock_id, qty_per_serving) VALUES(?,?,?)",
    [menu_item_id, stock_id, qty_per_serving], function(err){
      if (err) return res.status(500).json({error: err.message});
      res.json({id:this.lastID});
    });
});

app.delete('/menu/ingredients/:id', (req,res) => {
  db.run("DELETE FROM menu_item_ingredients WHERE id=?", [req.params.id], function(err){
    if (err) return res.status(500).json({error: err.message});
    res.json({success:true});
  });
});

// --------- STOCK ----------
app.get('/stock', (req,res) => {
  db.all("SELECT * FROM stock ORDER BY name", [], (err,rows) => {
    if (err) return res.status(500).json({error: err.message});
    res.json(rows);
  });
});

app.post('/stock', (req,res) => {
  const {name, unit, quantity, cost_per_unit} = req.body;
  db.run("INSERT INTO stock(name,unit,quantity,cost_per_unit) VALUES(?,?,?,?)",
    [name, unit, quantity || 0, cost_per_unit || 0], function(err){
      if (err) return res.status(500).json({error: err.message});
      res.json({id:this.lastID});
    });
});

app.put('/stock/:id', (req,res) => {
  const {quantity, cost_per_unit} = req.body;
  db.run("UPDATE stock SET quantity = COALESCE(?, quantity), cost_per_unit = COALESCE(?, cost_per_unit) WHERE id = ?",
    [quantity, cost_per_unit, req.params.id], function(err){
      if (err) return res.status(500).json({error: err.message});
      res.json({success:true});
    });
});

// --------- ORDERS (create using menu item ids & qty) ----------
app.post('/orders', (req,res) => {
  const {server_id, table_number, items} = req.body;
  // items = [{id: menu_item_id, qty}]
  if (!items || !Array.isArray(items) || items.length===0) return res.status(400).json({error:'No items'});
  const ids = items.map(i=>i.id);
  const placeholders = ids.map(()=>'?').join(',');
  db.all(`SELECT id,name,price FROM menu_items WHERE id IN (${placeholders})`, ids, (err, menuRows) => {
    if (err) return res.status(500).json({error: err.message});
    let total = 0;
    const detailed = items.map(it=>{
      const m = menuRows.find(r=>r.id === it.id);
      const price = m ? m.price : 0;
      total += price * it.qty;
      return {menu_item_id: it.id, item_name: m ? m.name : 'Unknown', qty: it.qty, price};
    });

    db.run("INSERT INTO orders(server_id, table_number, status, total_price) VALUES(?,?,?,?)",
      [server_id || null, table_number || null, 'pending', total], function(err){
        if (err) return res.status(500).json({error: err.message});
        const orderId = this.lastID;
        const stmt = db.prepare("INSERT INTO order_items(order_id,menu_item_id,item_name,qty,price) VALUES(?,?,?,?,?)");
        detailed.forEach(d => stmt.run(orderId, d.menu_item_id, d.item_name, d.qty, d.price));
        stmt.finalize();
        res.json({order_id: orderId});
      });
  });
});

// pay order: update status, insert income, and deduct stock based on menu_item_ingredients mapping
app.post('/orders/:id/pay', (req,res) => {
  const id = req.params.id;
  db.get("SELECT * FROM orders WHERE id = ?", [id], (err, order) => {
    if (err || !order) return res.status(404).json({error:'Order not found'});
    if (order.status === 'paid') return res.json({success:true});

    db.all("SELECT * FROM order_items WHERE order_id = ?", [id], (err, items) => {
      if (err) return res.status(500).json({error: err.message});

      // For each order item, get its ingredient mapping and deduct stock
      const updates = [];
      const promises = items.map(item => new Promise((resolve, reject) => {
        db.all("SELECT stock_id, qty_per_serving FROM menu_item_ingredients WHERE menu_item_id = ?", [item.menu_item_id], (err, ingr)=>{
          if (err) return resolve(); // skip on error
          if (!ingr || ingr.length===0) return resolve();
          // for each ingredient, deduct stock.qty -= qty_per_serving * item.qty
          ingr.forEach(g=>{
            const deduct = g.qty_per_serving * item.qty;
            db.run("UPDATE stock SET quantity = quantity - ? WHERE id = ?", [deduct, g.stock_id], function(err){
              // ignore errors for now
            });
          });
          resolve();
        });
      }));

      Promise.all(promises).then(()=> {
        db.run("UPDATE orders SET status = 'paid' WHERE id = ?", [id]);
        db.run("INSERT INTO income_expenses(type,description,amount) VALUES(?,?,?)",
          ['income', `Order #${id} payment`, order.total_price]);
        res.json({success:true});
      });
    });
  });
});

app.get('/orders', (req,res) => {
  db.all("SELECT * FROM orders ORDER BY created_at DESC", [], (err, rows) => {
    if (err) return res.status(500).json({error: err.message});
    res.json(rows);
  });
});

app.get('/orders/:id/items', (req,res) => {
  db.all("SELECT * FROM order_items WHERE order_id = ?", [req.params.id], (err,rows)=>{
    if (err) return res.status(500).json({error: err.message});
    res.json(rows);
  });
});

// --------- FINANCE ----------
app.post('/finance', (req,res) => {
  const {type, description, amount} = req.body;
  db.run("INSERT INTO income_expenses(type,description,amount) VALUES(?,?,?)", [type, description, amount], function(err){
    if (err) return res.status(500).json({error: err.message});
    res.json({id: this.lastID});
  });
});

app.get('/finance', (req,res) => {
  db.all("SELECT * FROM income_expenses ORDER BY created_at DESC", [], (err,rows)=>{
    if (err) return res.status(500).json({error: err.message});
    res.json(rows);
  });
});

// --------- REPORTS ----------
// basic profit report: sum(income) - sum(expense) - cost_of_goods_sold
app.get('/reports/daily', (req,res) => {
  // optional date param yyyy-mm-dd
  const day = req.query.date; // if none, use today by SQLite date('now')
  const dateFilter = day ? `DATE(created_at) = DATE('${day}')` : "DATE(created_at) = DATE('now')";
  const out = {};
  db.get(`SELECT COALESCE(SUM(amount),0) AS income FROM income_expenses WHERE type='income' AND ${dateFilter}`, [], (err,row)=>{
    out.income = row ? row.income : 0;
    db.get(`SELECT COALESCE(SUM(amount),0) AS expense FROM income_expenses WHERE type='expense' AND ${dateFilter}`, [], (err,row2)=>{
      out.expense = row2 ? row2.expense : 0;
      // estimate COGS by summing used stock * cost_per_unit from orders paid that day
      // find order_items for orders paid that day
      db.all(`SELECT oi.menu_item_id, oi.qty FROM order_items oi
              JOIN orders o ON oi.order_id = o.id
              WHERE o.status='paid' AND ${dateFilter}`, [], (err, orderItems)=>{
        if (!orderItems || orderItems.length===0) {
          out.cogs = 0;
          out.profit = out.income - out.expense - out.cogs;
          return res.json(out);
        }
        // for each menu_item_id, get its ingredients and compute cost
        let totalCost = 0;
        const tasks = orderItems.map(oi => new Promise((resolve,reject)=>{
          db.all("SELECT mii.qty_per_serving, s.cost_per_unit FROM menu_item_ingredients mii JOIN stock s ON mii.stock_id = s.id WHERE mii.menu_item_id = ?", [oi.menu_item_id], (err, rows)=>{
            if (rows && rows.length) {
              rows.forEach(r => {
                totalCost += (r.qty_per_serving * oi.qty) * (r.cost_per_unit || 0);
              });
            }
            resolve();
          });
        }));
        Promise.all(tasks).then(()=>{
          out.cogs = totalCost;
          out.profit = out.income - out.expense - out.cogs;
          res.json(out);
        });
      });
    });
  });
});

// start server
const PORT = process.env.PORT || 4000;
app.listen(PORT, ()=> console.log(`Canelle Server running on :${PORT}`));
