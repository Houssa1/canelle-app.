# Canelle - Restaurant management starter

## What is included
- server/ : Node + Express + SQLite backend (API for menu, stock, orders, finance, reports)
- client/ : React single-file app (simple SPA) that talks to the server
- Dockerfiles + docker-compose.yml to run server and client with Docker

## Quick local run (without Docker)
1. Start server:
   cd server
   npm install
   node index.js
   (server runs on http://localhost:4000)

2. Start client:
   cd client
   npm install
   npm start
   (client runs on http://localhost:3000 and proxies to server endpoints)

## Quick run with Docker
docker-compose build
docker-compose up

## Default admin
When first run, a default admin is created:
user: admin
password: admin123

## Next steps
- Improve authentication flow on the client
- Add images for menu items (store URLs)
- Add receipts and printing integration
- Add mobile native app for waiters
